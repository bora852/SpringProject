package com.ssafy.model.repository;

import com.ssafy.model.dto.Reviews;

public interface ReviewsRepository {

	public int insert(Reviews review);

}

