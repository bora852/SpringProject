/**
 *
 */
package com.ssafy.model.service;

import com.ssafy.model.dto.Reviews;

public interface ReviewsService {
	public int insert(Reviews review);

}
