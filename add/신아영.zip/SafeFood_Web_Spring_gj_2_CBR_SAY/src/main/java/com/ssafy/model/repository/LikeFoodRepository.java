package com.ssafy.model.repository;

import com.ssafy.model.dto.LikeFood;


public interface LikeFoodRepository {

	public int insert(LikeFood likefood);

}

