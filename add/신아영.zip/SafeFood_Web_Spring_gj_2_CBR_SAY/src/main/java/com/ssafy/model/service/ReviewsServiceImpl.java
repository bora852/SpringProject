package com.ssafy.model.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.model.dto.Reviews;
import com.ssafy.model.repository.ReviewsRepository;


@Service
public class ReviewsServiceImpl implements ReviewsService {
	private ReviewsRepository reviewsRepo;

	@Autowired
	public ReviewsServiceImpl(ReviewsRepository repo) {
		reviewsRepo = repo;
	}

	@Override
	public int insert(Reviews review) {
		return reviewsRepo.insert(review);
	}

}
