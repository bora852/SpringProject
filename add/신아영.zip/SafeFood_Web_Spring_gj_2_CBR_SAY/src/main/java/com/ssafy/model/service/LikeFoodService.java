/**
 *
 */
package com.ssafy.model.service;

import com.ssafy.model.dto.LikeFood;

public interface LikeFoodService {
	public int insert(LikeFood likefood);

}
